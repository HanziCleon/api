# Anime Streaming Project

## 🚀 Cara Jalankan

### 1. Backend
```bash
cd backend
npm install
npm start
```

### 2. Frontend
```bash
cd frontend
npm install
npm run dev
```

Lalu buka http://localhost:5173 di browser.
